package com.sense.enrutamiento;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DojoController {
	@RequestMapping("/{rutavariable}")
	public String showMessage(@PathVariable("rutavariable")String rutavariable) {
		if(rutavariable.equals("Dojo")) {
			return "Hola Dojo";
		}if(rutavariable.equals("burbank-dojo")) {
			return "El Dojo Burbank está localizado al sur de California";
		}if(rutavariable.equals("san-jose")) {
			return "El dojo SJ es el cuartel general";
		}
		return null; 
	}

}
